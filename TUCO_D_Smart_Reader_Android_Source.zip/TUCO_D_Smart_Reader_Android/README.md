# TUCO D Smart Reader — Android APK source

Android WebView wrapper for the existing TUCO D Smart Reader HTML prototype.

## Features
- Android launcher app named TUCO D Smart Reader.
- Bundles the HTML locally in the app.
- Supports phone camera and gallery selection from the HTML image input.
- Uses internet only to load the Tesseract.js OCR engine from its CDN.
- OCR and image processing run in the WebView; the photographed image is not sent to an app backend.

## GitHub Actions
Upload this ZIP to the root of your GitHub repository as `TUCO_D_Smart_Reader_Android_Source.zip`.
Add the workflow at `.github/workflows/build-apk.yml`.
Run it from Actions → Build TUCO D Android APK → Run workflow.
Download `app-debug.apk` from the run's Artifacts section.

## Local build
Requires JDK 17, Android SDK Platform 35 and Gradle 8.9:
`gradle --no-daemon assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

This is a debug APK for testing, not a Play Store signed release. Voice playback is not included yet.
