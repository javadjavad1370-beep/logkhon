# TUCO D Smart Reader V3 — Android source

Android WebView wrapper for the V3 TUCO D reader.

## Recommended capture method
Take one close-up photo for each Part (01–04). A single full-screen photo makes the characters too small for dependable OCR. The app stores each Part's photo separately while you process it.

## V3 processing pipeline
1. Mark the four corners of the selected Part's data grid (top-left, top-right, bottom-right, bottom-left).
2. OpenCV.js applies perspective correction to rectify the table.
3. OpenCV analyzes horizontal grid rules and blue-row color to propose the selected row.
4. OpenCV analyzes vertical separators and proposes the expected number of columns for that Part.
5. Operator confirms the row and adjusts column separators if needed.
6. Tesseract.js reads each numeric cell separately. If the first reading is uncertain, two additional preprocessing variants are tried. Conflicting OCR candidates are shown for manual selection.

## GitHub Actions
Upload `TUCO_D_Smart_Reader_V3_Android_Source.zip` to the repository root and add the workflow at `.github/workflows/build-apk.yml`.
Run **Actions → Build TUCO D Smart Reader V3 APK → Run workflow** and download the `TUCO-D-Smart-Reader-V3-APK` artifact.

## Important
- OpenCV.js and Tesseract.js are loaded from public CDNs. Internet is needed to load these engines.
- Image processing runs locally in the WebView; photos are not uploaded to an application server.
- This is an operator-assisted prototype, not a certified measurement system. Compare every extracted value with the TUCO D screen before use.
- No voice playback is included in V3.
